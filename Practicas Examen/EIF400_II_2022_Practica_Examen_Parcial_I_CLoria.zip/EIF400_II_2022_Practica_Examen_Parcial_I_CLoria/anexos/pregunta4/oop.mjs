


export function cousins(obj1, obj2){
    // TO DO
}







