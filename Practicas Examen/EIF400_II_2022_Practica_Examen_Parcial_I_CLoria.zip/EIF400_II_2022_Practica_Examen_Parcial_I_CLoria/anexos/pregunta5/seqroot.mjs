export function* seqRoot(a){
    //TO DO
}


export function first(gen, test){
    // TO DO
}

export function root(a, {max=20, epsilon=1e-10}){
    // TO DO
    return {n:0, x:0}
}

